# Dependencias:

* Qt5
* CMake >= 2.8.11

# Instrucciones

cd build
cmake ..
make
./lepp-delaunay

# Cambio de triangulación

Modificar línea 12 de *Model.cpp*, y cambiar el número por algúno de los siguientes: 1, 2, 3, 4
