# Dependencias:

* Qt5
* CMake >= 2.8.11

# Instrucciones

cd build
cmake ..
make
./lepp-delaunay

# Notas
* Esta es la versión v1 de esta tarea.
* La versión v2 de esta tarea está en la otra "Tarea 2 (versión 2)" habilitada en U-Cursos.
